package com.voab.jo17_tactical_manager

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
