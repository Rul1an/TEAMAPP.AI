import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../screens/dashboard/dashboard_screen.dart';
import '../screens/players/players_screen.dart';
import '../screens/players/player_detail_screen.dart';
import '../screens/players/add_player_screen.dart';
import '../screens/players/edit_player_screen.dart';
import '../screens/training/training_screen.dart';
import '../screens/training/training_attendance_screen.dart';
import '../screens/training/edit_training_screen.dart';
import '../screens/training/add_training_screen.dart';
import '../screens/matches/matches_screen.dart';
import '../screens/matches/match_detail_screen.dart';
import '../screens/matches/add_match_screen.dart';
import '../screens/matches/edit_match_screen.dart';
import '../screens/matches/lineup_builder_screen.dart';
import '../widgets/common/main_scaffold.dart';

final router = GoRouter(
  initialLocation: '/dashboard',
  routes: [
    ShellRoute(
      builder: (context, state, child) => MainScaffold(child: child),
      routes: [
        GoRoute(
          path: '/dashboard',
          name: 'dashboard',
          pageBuilder: (context, state) => const NoTransitionPage(
            child: DashboardScreen(),
          ),
        ),
        GoRoute(
          path: '/players',
          name: 'players',
          pageBuilder: (context, state) => const NoTransitionPage(
            child: PlayersScreen(),
          ),
          routes: [
            GoRoute(
              path: 'add',
              name: 'add-player',
              builder: (context, state) => const AddPlayerScreen(),
            ),
            GoRoute(
              path: ':playerId',
              name: 'player-detail',
              builder: (context, state) => PlayerDetailScreen(
                playerId: state.pathParameters['playerId'] ?? '',
              ),
            ),
            GoRoute(
              path: ':playerId/edit',
              builder: (context, state) => EditPlayerScreen(
                playerId: state.pathParameters['playerId'] ?? '',
              ),
            ),
          ],
        ),
        GoRoute(
          path: '/training',
          name: 'training',
          pageBuilder: (context, state) => const NoTransitionPage(
            child: TrainingScreen(),
          ),
          routes: [
            GoRoute(
              path: 'add',
              name: 'add-training',
              builder: (context, state) => const AddTrainingScreen(),
            ),
            GoRoute(
              path: 'attendance/:id',
              builder: (context, state) => TrainingAttendanceScreen(
                trainingId: state.pathParameters['id']!,
              ),
            ),
            GoRoute(
              path: 'edit/:id',
              builder: (context, state) => EditTrainingScreen(
                trainingId: state.pathParameters['id']!,
              ),
            ),
          ],
        ),
        GoRoute(
          path: '/matches',
          name: 'matches',
          pageBuilder: (context, state) => const NoTransitionPage(
            child: MatchesScreen(),
          ),
          routes: [
            GoRoute(
              path: 'add',
              name: 'add-match',
              builder: (context, state) => const AddMatchScreen(),
            ),
            GoRoute(
              path: ':matchId',
              builder: (context, state) => MatchDetailScreen(
                matchId: state.pathParameters['matchId'] ?? '',
              ),
            ),
            GoRoute(
              path: ':matchId/edit',
              builder: (context, state) => EditMatchScreen(
                matchId: state.pathParameters['matchId'] ?? '',
              ),
            ),
          ],
        ),
        GoRoute(
          path: '/lineup',
          name: 'lineup-builder',
          pageBuilder: (context, state) {
            final matchId = state.uri.queryParameters['matchId'];
            return NoTransitionPage(
              child: LineupBuilderScreen(matchId: matchId),
            );
          },
        ),
      ],
    ),
  ],
);
