import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:intl/intl.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../models/player.dart';
import '../../models/match.dart';
import '../../providers/database_provider.dart';
import '../../utils/colors.dart';

class PlayerDetailScreen extends ConsumerStatefulWidget {
  final String playerId;

  const PlayerDetailScreen({
    super.key,
    required this.playerId,
  });

  @override
  ConsumerState<PlayerDetailScreen> createState() => _PlayerDetailScreenState();
}

class _PlayerDetailScreenState extends ConsumerState<PlayerDetailScreen> {
  @override
  Widget build(BuildContext context) {
    final playersAsync = ref.watch(playersProvider);
    final matchesAsync = ref.watch(matchesProvider);
    final isDesktop = MediaQuery.of(context).size.width > 900;
    final isTablet = MediaQuery.of(context).size.width > 600;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Speler Details'),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit),
            onPressed: () {
              context.go('/players/${widget.playerId}/edit');
            },
          ),
        ],
      ),
      body: playersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('Fout: $error')),
        data: (players) {
          final player = players.firstWhere(
            (p) => p.id.toString() == widget.playerId,
            orElse: () {
              final newPlayer = Player();
              newPlayer.firstName = 'Onbekend';
              newPlayer.lastName = '';
              return newPlayer;
            },
          );

          if (player.id == 0) {
            return const Center(child: Text('Speler niet gevonden'));
          }

          return SingleChildScrollView(
            padding: EdgeInsets.all(isDesktop ? 24 : 16),
            child: Center(
              child: ConstrainedBox(
                constraints: BoxConstraints(maxWidth: isDesktop ? 1200 : double.infinity),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    _buildPlayerHeader(player),
                    const SizedBox(height: 24),
                    if (isDesktop || isTablet)
                      Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Expanded(
                            flex: 2,
                            child: Column(
                              children: [
                                _buildStatisticsCards(player),
                                const SizedBox(height: 24),
                                _buildMinutesChart(player),
                              ],
                            ),
                          ),
                          const SizedBox(width: 24),
                          Expanded(
                            child: Column(
                              children: [
                                _buildRecentMatches(player, matchesAsync),
                                const SizedBox(height: 24),
                                _buildPersonalInfo(player),
                              ],
                            ),
                          ),
                        ],
                      )
                    else ...[
                      _buildStatisticsCards(player),
                      const SizedBox(height: 24),
                      _buildMinutesChart(player),
                      const SizedBox(height: 24),
                      _buildRecentMatches(player, matchesAsync),
                      const SizedBox(height: 24),
                      _buildPersonalInfo(player),
                    ],
                  ],
                ),
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _buildPlayerHeader(Player player) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            CircleAvatar(
              radius: 40,
              backgroundColor: getPositionColor(player.position),
              child: Text(
                player.jerseyNumber.toString(),
                style: const TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Colors.white,
                ),
              ),
            ),
            const SizedBox(width: 16),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    player.name,
                    style: Theme.of(context).textTheme.headlineSmall,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      Chip(
                        label: Text(_getPositionName(player.position)),
                        backgroundColor: getPositionColor(player.position).withOpacity(0.2),
                      ),
                      const SizedBox(width: 8),
                      Text(
                        '${player.age} jaar',
                        style: Theme.of(context).textTheme.bodyLarge,
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStatisticsCards(Player player) {
    return GridView.count(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      crossAxisCount: 2,
      childAspectRatio: 1.5,
      mainAxisSpacing: 16,
      crossAxisSpacing: 16,
      children: [
        _buildStatCard(
          'Speelminuten',
          '${player.matchMinutesPercentage.toStringAsFixed(1)}%',
          Icons.timer,
          Colors.blue,
          subtitle: '${player.minutesPlayed} min totaal',
        ),
        _buildStatCard(
          'Wedstrijden',
          '${player.matchesPlayed}',
          Icons.sports_soccer,
          Colors.green,
          subtitle: 'Van ${player.matchesInSelection} selecties',
        ),
        _buildStatCard(
          'Gem. Minuten',
          '${player.averageMinutesPerMatch.toStringAsFixed(0)}',
          Icons.av_timer,
          Colors.orange,
          subtitle: 'Per wedstrijd',
        ),
        _buildStatCard(
          'Training',
          '${player.attendancePercentage.toStringAsFixed(0)}%',
          Icons.fitness_center,
          Colors.purple,
          subtitle: '${player.trainingsAttended}/${player.trainingsTotal}',
        ),
      ],
    );
  }

  Widget _buildStatCard(
    String title,
    String value,
    IconData icon,
    Color color, {
    String? subtitle,
  }) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, color: color, size: 32),
            const SizedBox(height: 8),
            Text(
              value,
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.bold,
                color: color,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodySmall,
            ),
            if (subtitle != null) ...[
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Colors.grey,
                    ),
              ),
            ],
          ],
        ),
      ),
    );
  }

  Widget _buildMinutesChart(Player player) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Speelminuten Overzicht',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            SizedBox(
              height: 200,
              child: _buildBarChart(player),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildBarChart(Player player) {
    // Mock data voor demonstratie - in productie zou dit uit de match history komen
    final data = [
      _BarData('Week 1', 80, 80),
      _BarData('Week 2', 65, 80),
      _BarData('Week 3', 0, 0),
      _BarData('Week 4', 80, 80),
      _BarData('Week 5', 45, 80),
    ];

    return BarChart(
      BarChartData(
        alignment: BarChartAlignment.spaceAround,
        maxY: 100,
        barTouchData: BarTouchData(
          enabled: true,
          touchTooltipData: BarTouchTooltipData(
            getTooltipItem: (group, groupIndex, rod, rodIndex) {
              return BarTooltipItem(
                '${rod.toY.toStringAsFixed(0)}%',
                const TextStyle(color: Colors.white),
              );
            },
          ),
        ),
        titlesData: FlTitlesData(
          show: true,
          bottomTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              getTitlesWidget: (value, meta) {
                if (value.toInt() < data.length) {
                  return Text(
                    data[value.toInt()].label,
                    style: const TextStyle(fontSize: 10),
                  );
                }
                return const Text('');
              },
            ),
          ),
          leftTitles: AxisTitles(
            sideTitles: SideTitles(
              showTitles: true,
              reservedSize: 30,
              getTitlesWidget: (value, meta) {
                return Text(
                  '${value.toInt()}%',
                  style: const TextStyle(fontSize: 10),
                );
              },
            ),
          ),
          topTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
          rightTitles: const AxisTitles(
            sideTitles: SideTitles(showTitles: false),
          ),
        ),
        borderData: FlBorderData(show: false),
        barGroups: data.asMap().entries.map((entry) {
          final index = entry.key;
          final item = entry.value;
          final percentage = item.maxMinutes > 0
              ? (item.playedMinutes / item.maxMinutes) * 100
              : 0;

          return BarChartGroupData(
            x: index,
            barRods: [
              BarChartRodData(
                toY: percentage.toDouble(),
                color: percentage >= 75
                    ? Colors.green
                    : percentage >= 50
                        ? Colors.orange
                        : Colors.red,
                width: 20,
                borderRadius: const BorderRadius.vertical(
                  top: Radius.circular(4),
                ),
              ),
            ],
          );
        }).toList(),
      ),
    );
  }

  Widget _buildRecentMatches(Player player, AsyncValue<List<Match>> matchesAsync) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Recente Wedstrijden',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            matchesAsync.when(
              loading: () => const CircularProgressIndicator(),
              error: (error, stack) => Text('Fout: $error'),
              data: (matches) {
                final recentMatches = matches
                    .where((m) => m.status == MatchStatus.completed)
                    .take(5)
                    .toList();

                if (recentMatches.isEmpty) {
                  return const Text('Nog geen wedstrijden gespeeld');
                }

                return Column(
                  children: recentMatches.map((match) {
                    return ListTile(
                      contentPadding: EdgeInsets.zero,
                      leading: CircleAvatar(
                        backgroundColor: _getResultColor(match.result),
                        child: Text(
                          _getResultLetter(match.result),
                          style: const TextStyle(
                            color: Colors.white,
                            fontWeight: FontWeight.bold,
                          ),
                        ),
                      ),
                      title: Text(match.opponent),
                      subtitle: Text(
                        DateFormat('d MMM', 'nl_NL').format(match.date),
                      ),
                      trailing: Text(
                        '${match.teamScore ?? 0} - ${match.opponentScore ?? 0}',
                        style: const TextStyle(fontWeight: FontWeight.bold),
                      ),
                    );
                  }).toList(),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPersonalInfo(Player player) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Persoonlijke Informatie',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            _buildInfoRow('Geboortedatum', DateFormat('d MMMM yyyy', 'nl_NL').format(player.birthDate)),
            _buildInfoRow('Lengte', '${player.height} cm'),
            _buildInfoRow('Gewicht', '${player.weight} kg'),
            _buildInfoRow('Voorkeur voet', player.preferredFoot == PreferredFoot.left ? 'Links' : 'Rechts'),
            if (player.email != null && player.email!.isNotEmpty)
              _buildInfoRow('Email', player.email!),
          ],
        ),
      ),
    );
  }

  Widget _buildInfoRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 120,
            child: Text(
              label,
              style: const TextStyle(
                fontWeight: FontWeight.w500,
                color: Colors.grey,
              ),
            ),
          ),
          Expanded(
            child: Text(value),
          ),
        ],
      ),
    );
  }

  String _getPositionName(Position position) {
    switch (position) {
      case Position.goalkeeper:
        return 'Keeper';
      case Position.defender:
        return 'Verdediger';
      case Position.midfielder:
        return 'Middenvelder';
      case Position.forward:
        return 'Aanvaller';
    }
  }

  Color _getResultColor(MatchResult? result) {
    switch (result) {
      case MatchResult.win:
        return Colors.green;
      case MatchResult.draw:
        return Colors.orange;
      case MatchResult.loss:
        return Colors.red;
      default:
        return Colors.grey;
    }
  }

  String _getResultLetter(MatchResult? result) {
    switch (result) {
      case MatchResult.win:
        return 'W';
      case MatchResult.draw:
        return 'G';
      case MatchResult.loss:
        return 'V';
      default:
        return '-';
    }
  }
}

class _BarData {
  final String label;
  final double playedMinutes;
  final double maxMinutes;

  _BarData(this.label, this.playedMinutes, this.maxMinutes);
}
