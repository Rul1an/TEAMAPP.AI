import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../providers/players_provider.dart';
import '../../models/player.dart';
import '../../utils/colors.dart';
import '../../providers/database_provider.dart';
import '../../widgets/player/player_card.dart';
import '../../services/export_service.dart';

class PlayersScreen extends ConsumerStatefulWidget {
  const PlayersScreen({super.key});

  @override
  ConsumerState<PlayersScreen> createState() => _PlayersScreenState();
}

class _PlayersScreenState extends ConsumerState<PlayersScreen> {
  String _searchQuery = '';
  Position? _selectedPosition;

  @override
  Widget build(BuildContext context) {
    final playersAsync = ref.watch(playersNotifierProvider);
    final isDesktop = MediaQuery.of(context).size.width > 900;
    final isTablet = MediaQuery.of(context).size.width > 600;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Spelers'),
        actions: [
          IconButton(
            icon: const Icon(Icons.person_add),
            onPressed: () => context.go('/players/add'),
          ),
          PopupMenuButton<String>(
            icon: const Icon(Icons.download),
            onSelected: (value) async {
              try {
                switch (value) {
                  case 'pdf':
                    await ExportService().exportPlayersToPDF();
                    break;
                  case 'excel':
                    await ExportService().exportPlayersToExcel();
                    break;
                }
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text('Export gestart'),
                      backgroundColor: Colors.green,
                    ),
                  );
                }
              } catch (e) {
                if (mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    SnackBar(
                      content: Text('Export mislukt: $e'),
                      backgroundColor: Colors.red,
                    ),
                  );
                }
              }
            },
            itemBuilder: (context) => [
              const PopupMenuItem(
                value: 'pdf',
                child: ListTile(
                  leading: Icon(Icons.picture_as_pdf),
                  title: Text('Exporteer naar PDF'),
                ),
              ),
              const PopupMenuItem(
                value: 'excel',
                child: ListTile(
                  leading: Icon(Icons.table_chart),
                  title: Text('Exporteer naar Excel'),
                ),
              ),
            ],
          ),
        ],
      ),
      body: Column(
        children: [
          // Search and Filter Bar
          Container(
            padding: EdgeInsets.all(isDesktop ? 24.0 : 16.0),
            child: Row(
              children: [
                Expanded(
                  flex: isDesktop ? 3 : 1,
                  child: TextField(
                    decoration: InputDecoration(
                      hintText: 'Zoek op naam of rugnummer...',
                      prefixIcon: const Icon(Icons.search),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                      filled: true,
                    ),
                    onChanged: (value) {
                      setState(() {
                        _searchQuery = value.toLowerCase();
                      });
                    },
                  ),
                ),
                if (isTablet) ...[
                  const SizedBox(width: 16),
                  SizedBox(
                    width: 200,
                    child: DropdownButtonFormField<Position?>(
                      value: _selectedPosition,
                      decoration: InputDecoration(
                        labelText: 'Positie',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                        filled: true,
                      ),
                      items: [
                        const DropdownMenuItem(
                          value: null,
                          child: Text('Alle posities'),
                        ),
                        ...Position.values.map((position) => DropdownMenuItem(
                              value: position,
                              child: Text(_getPositionText(position)),
                            )),
                      ],
                      onChanged: (value) {
                        setState(() {
                          _selectedPosition = value;
                        });
                      },
                    ),
                  ),
                ],
              ],
            ),
          ),
          // Position filter chips for mobile
          if (!isTablet)
            Container(
              height: 50,
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  FilterChip(
                    label: const Text('Alle'),
                    selected: _selectedPosition == null,
                    onSelected: (selected) {
                      setState(() {
                        _selectedPosition = null;
                      });
                    },
                  ),
                  const SizedBox(width: 8),
                  ...Position.values.map((position) => Padding(
                        padding: const EdgeInsets.only(right: 8),
                        child: FilterChip(
                          label: Text(_getPositionText(position)),
                          selected: _selectedPosition == position,
                          onSelected: (selected) {
                            setState(() {
                              _selectedPosition = selected ? position : null;
                            });
                          },
                        ),
                      )),
                ],
              ),
            ),
          const SizedBox(height: 8),
          // Players Grid/List
          Expanded(
            child: playersAsync.when(
              data: (players) {
                final filteredPlayers = players.where((player) {
                  final fullName = '${player.firstName} ${player.lastName}'.toLowerCase();
                  final matchesSearch = _searchQuery.isEmpty ||
                      fullName.contains(_searchQuery) ||
                      player.jerseyNumber.toString().contains(_searchQuery);
                  final matchesPosition = _selectedPosition == null ||
                      player.position == _selectedPosition;
                  return matchesSearch && matchesPosition;
                }).toList();

                if (filteredPlayers.isEmpty) {
                  return Center(
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(
                          Icons.person_off,
                          size: 64,
                          color: Colors.grey[400],
                        ),
                        const SizedBox(height: 16),
                        Text(
                          'Geen spelers gevonden',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                        const SizedBox(height: 8),
                        ElevatedButton.icon(
                          onPressed: () => context.go('/players/add'),
                          icon: const Icon(Icons.person_add),
                          label: const Text('Voeg eerste speler toe'),
                        ),
                      ],
                    ),
                  );
                }

                return RefreshIndicator(
                  onRefresh: () async {
                    await ref.read(playersNotifierProvider.notifier).loadPlayers();
                  },
                  child: isDesktop
                      ? GridView.builder(
                          padding: const EdgeInsets.all(24),
                          gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                            maxCrossAxisExtent: 400,
                            childAspectRatio: 1.5,
                            crossAxisSpacing: 16,
                            mainAxisSpacing: 16,
                          ),
                          itemCount: filteredPlayers.length,
                          itemBuilder: (context, index) {
                            final player = filteredPlayers[index];
                            return _PlayerCard(
                              player: player,
                              onTap: () => context.go('/players/${player.id}'),
                            );
                          },
                        )
                      : ListView.builder(
                          padding: EdgeInsets.all(isTablet ? 24 : 16),
                          itemCount: filteredPlayers.length,
                          itemBuilder: (context, index) {
                            final player = filteredPlayers[index];
                            return Padding(
                              padding: const EdgeInsets.only(bottom: 8),
                              child: _PlayerCard(
                                player: player,
                                onTap: () => context.go('/players/${player.id}'),
                              ),
                            );
                          },
                        ),
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (error, stack) => Center(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(
                      Icons.error_outline,
                      size: 64,
                      color: Colors.red,
                    ),
                    const SizedBox(height: 16),
                    Text(
                      'Er ging iets mis',
                      style: Theme.of(context).textTheme.titleLarge,
                    ),
                    const SizedBox(height: 8),
                    Text(error.toString()),
                    const SizedBox(height: 16),
                    ElevatedButton(
                      onPressed: () => ref.read(playersNotifierProvider.notifier).loadPlayers(),
                      child: const Text('Probeer opnieuw'),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: isDesktop
          ? null
          : FloatingActionButton(
              onPressed: () => context.go('/players/add'),
              child: const Icon(Icons.person_add),
            ),
    );
  }

  String _getPositionText(Position position) {
    switch (position) {
      case Position.goalkeeper:
        return 'Keeper';
      case Position.defender:
        return 'Verdediger';
      case Position.midfielder:
        return 'Middenvelder';
      case Position.forward:
        return 'Aanvaller';
    }
  }
}

class _PlayerCard extends StatelessWidget {
  final Player player;
  final VoidCallback onTap;

  const _PlayerCard({
    required this.player,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(12),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Row(
            children: [
              CircleAvatar(
                radius: 30,
                backgroundColor: getPositionColor(player.position),
                child: Text(
                  player.jerseyNumber.toString(),
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '${player.firstName} ${player.lastName}',
                      style: Theme.of(context).textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      _getPositionText(player.position),
                      style: Theme.of(context).textTheme.bodyMedium,
                    ),
                    const SizedBox(height: 4),
                    Row(
                      children: [
                        Expanded(
                          child: Row(
                            children: [
                              Icon(Icons.sports_soccer, size: 14, color: Colors.grey[600]),
                              const SizedBox(width: 2),
                              Flexible(
                                child: Text(
                                  '${player.matchesPlayed} wedstr.',
                                  style: Theme.of(context).textTheme.bodySmall,
                                  overflow: TextOverflow.ellipsis,
                                ),
                              ),
                            ],
                          ),
                        ),
                        const SizedBox(width: 8),
                        Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(Icons.timer, size: 14, color: Colors.grey[600]),
                            const SizedBox(width: 2),
                            Text(
                              '${player.matchMinutesPercentage.toStringAsFixed(0)}%',
                              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                                color: player.matchMinutesPercentage >= 75
                                    ? Colors.green
                                    : player.matchMinutesPercentage >= 50
                                        ? Colors.orange
                                        : Colors.red,
                                fontWeight: FontWeight.bold,
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ),
              Icon(
                Icons.chevron_right,
                color: Colors.grey[400],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getPositionText(Position position) {
    switch (position) {
      case Position.goalkeeper:
        return 'Keeper';
      case Position.defender:
        return 'Verdediger';
      case Position.midfielder:
        return 'Middenvelder';
      case Position.forward:
        return 'Aanvaller';
    }
  }
}
