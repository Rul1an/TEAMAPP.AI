import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:fl_chart/fl_chart.dart';
import '../../providers/statistics_provider.dart';
import '../../providers/matches_provider.dart';
import '../../providers/trainings_provider.dart';
import '../../models/match.dart';
import '../../models/training.dart';
import 'package:intl/intl.dart';
import 'package:go_router/go_router.dart';

class DashboardScreen extends ConsumerWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final statisticsAsync = ref.watch(statisticsProvider);
    final upcomingMatchesAsync = ref.watch(upcomingMatchesProvider);
    final upcomingTrainingsAsync = ref.watch(upcomingTrainingsProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dashboard'),
        actions: [
          IconButton(
            icon: const Icon(Icons.sports_soccer),
            onPressed: () => context.go('/lineup'),
            tooltip: 'Opstelling Maken',
          ),
        ],
      ),
      body: statisticsAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('Error: $error')),
        data: (statistics) => SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // Statistics Cards
              _buildStatisticsCards(context, statistics),
              const SizedBox(height: 24),

              // Performance Chart
              _buildPerformanceChart(context, statistics),
              const SizedBox(height: 24),

              // Upcoming Matches
              Text(
                'Aankomende Wedstrijden',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              upcomingMatchesAsync.when(
                loading: () => const CircularProgressIndicator(),
                error: (error, stack) => Text('Error: $error'),
                data: (matches) => _buildUpcomingMatches(context, matches),
              ),
              const SizedBox(height: 24),

              // Upcoming Trainings
              Text(
                'Aankomende Trainingen',
                style: Theme.of(context).textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              upcomingTrainingsAsync.when(
                loading: () => const CircularProgressIndicator(),
                error: (error, stack) => Text('Error: $error'),
                data: (trainings) => _buildUpcomingTrainings(context, trainings),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatisticsCards(BuildContext context, Map<String, dynamic> statistics) {
    return LayoutBuilder(
      builder: (context, constraints) {
        final crossAxisCount = constraints.maxWidth > 800 ? 4 : 2;
        final childAspectRatio = constraints.maxWidth > 800 ? 1.5 : 1.2;

        return GridView.count(
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          crossAxisCount: crossAxisCount,
          childAspectRatio: childAspectRatio,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          children: [
            _buildStatCard(
              context,
              'Spelers',
              statistics['totalPlayers'].toString(),
              Icons.people,
              Colors.blue,
            ),
            _buildStatCard(
              context,
              'Wedstrijden',
              statistics['totalMatches'].toString(),
              Icons.sports_soccer,
              Colors.green,
            ),
            _buildStatCard(
              context,
              'Trainingen',
              statistics['totalTrainings'].toString(),
              Icons.fitness_center,
              Colors.orange,
            ),
            _buildStatCard(
              context,
              'Win %',
              '${statistics['winPercentage'].toStringAsFixed(1)}%',
              Icons.emoji_events,
              Colors.amber,
            ),
          ],
        );
      },
    );
  }

  Widget _buildStatCard(
    BuildContext context,
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
      elevation: 2,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 32, color: color),
            const SizedBox(height: 8),
            Text(
              value,
              style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            Text(
              title,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).textTheme.bodySmall?.color,
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildPerformanceChart(BuildContext context, Map<String, dynamic> statistics) {
    final wins = statistics['wins'] as int;
    final draws = statistics['draws'] as int;
    final losses = statistics['losses'] as int;
    final total = wins + draws + losses;

    if (total == 0) {
      return Card(
        child: Container(
          height: 300,
          padding: const EdgeInsets.all(16),
          child: const Center(
            child: Text('Nog geen wedstrijden gespeeld'),
          ),
        ),
      );
    }

    return Card(
      child: Container(
        height: 300,
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Wedstrijd Resultaten',
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: 16),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    child: PieChart(
                      PieChartData(
                        sections: [
                          PieChartSectionData(
                            value: wins.toDouble(),
                            title: 'W: $wins',
                            color: Colors.green,
                            radius: 60,
                          ),
                          PieChartSectionData(
                            value: draws.toDouble(),
                            title: 'G: $draws',
                            color: Colors.orange,
                            radius: 60,
                          ),
                          PieChartSectionData(
                            value: losses.toDouble(),
                            title: 'V: $losses',
                            color: Colors.red,
                            radius: 60,
                          ),
                        ],
                        sectionsSpace: 2,
                        centerSpaceRadius: 25,
                      ),
                    ),
                  ),
                  const SizedBox(width: 32),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      _buildLegendItem('Gewonnen', Colors.green, wins),
                      const SizedBox(height: 8),
                      _buildLegendItem('Gelijk', Colors.orange, draws),
                      const SizedBox(height: 8),
                      _buildLegendItem('Verloren', Colors.red, losses),
                      const Divider(height: 24),
                      Text(
                        'Doelpunten',
                        style: Theme.of(context).textTheme.titleMedium,
                      ),
                      const SizedBox(height: 4),
                      Text('Voor: ${statistics['goalsFor']}'),
                      Text('Tegen: ${statistics['goalsAgainst']}'),
                      Text('Saldo: ${statistics['goalDifference']}'),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildLegendItem(String label, Color color, int value) {
    return Row(
      children: [
        Container(
          width: 16,
          height: 16,
          color: color,
        ),
        const SizedBox(width: 8),
        Text('$label: $value'),
      ],
    );
  }

  Widget _buildUpcomingMatches(BuildContext context, List<Match> matches) {
    if (matches.isEmpty) {
      return Card(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: const Text('Geen aankomende wedstrijden'),
        ),
      );
    }

    return Column(
      children: matches.take(3).map((match) {
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: match.location == Location.home ? Colors.green : Colors.blue,
              child: Text(
                match.location == Location.home ? 'T' : 'U',
                style: const TextStyle(color: Colors.white),
              ),
            ),
            title: Text(match.opponent),
            subtitle: Text(
              '${DateFormat('dd MMM').format(match.date)} - ${match.venue}',
            ),
            trailing: Text(
              DateFormat('HH:mm').format(match.date),
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
        );
      }).toList(),
    );
  }

  Widget _buildUpcomingTrainings(BuildContext context, List<Training> trainings) {
    if (trainings.isEmpty) {
      return Card(
        child: Container(
          padding: const EdgeInsets.all(16),
          child: const Text('Geen aankomende trainingen'),
        ),
      );
    }

    return Column(
      children: trainings.take(3).map((training) {
        return Card(
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: _getTrainingColor(training.intensity),
              child: const Icon(Icons.fitness_center, color: Colors.white),
            ),
            title: Text(_getTrainingFocusText(training.focus)),
            subtitle: Text(
              '${DateFormat('dd MMM').format(training.date)} - ${training.location}',
            ),
            trailing: Text(
              '${training.duration} min',
              style: Theme.of(context).textTheme.titleMedium,
            ),
          ),
        );
      }).toList(),
    );
  }

  Color _getTrainingColor(TrainingIntensity intensity) {
    switch (intensity) {
      case TrainingIntensity.low:
        return Colors.green;
      case TrainingIntensity.medium:
        return Colors.orange;
      case TrainingIntensity.high:
        return Colors.red;
      case TrainingIntensity.recovery:
        return Colors.blue;
    }
  }

  String _getTrainingFocusText(TrainingFocus focus) {
    switch (focus) {
      case TrainingFocus.technical:
        return 'Techniek';
      case TrainingFocus.tactical:
        return 'Tactiek';
      case TrainingFocus.physical:
        return 'Fysiek';
      case TrainingFocus.mental:
        return 'Mentaal';
      case TrainingFocus.matchPrep:
        return 'Wedstrijdvoorbereiding';
    }
  }
}
