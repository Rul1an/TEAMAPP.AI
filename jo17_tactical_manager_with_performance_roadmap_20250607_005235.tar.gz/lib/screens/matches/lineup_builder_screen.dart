import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../models/player.dart';
import '../../models/team.dart';
import '../../models/match.dart';
import '../../providers/database_provider.dart';
import '../../services/database_service.dart';

class LineupBuilderScreen extends ConsumerStatefulWidget {
  final String? matchId;

  const LineupBuilderScreen({
    super.key,
    this.matchId,
  });

  @override
  ConsumerState<LineupBuilderScreen> createState() => _LineupBuilderScreenState();
}

class _LineupBuilderScreenState extends ConsumerState<LineupBuilderScreen> {
  Formation _selectedFormation = Formation.fourThreeThree;
  Map<String, Player?> _fieldPositions = {};
  List<Player> _benchPlayers = [];
  List<Player> _availablePlayers = [];
  Match? _match;

  @override
  void initState() {
    super.initState();
    _initializePositions();
    if (widget.matchId != null) {
      _loadMatch();
    }
  }

  Future<void> _loadMatch() async {
    final match = await DatabaseService().getMatch(int.parse(widget.matchId!));
    if (match != null && mounted) {
      setState(() {
        _match = match;
        if (match.selectedFormation != null) {
          _selectedFormation = match.selectedFormation!;
          _initializePositions();

          // Load existing lineup if available
          _loadExistingLineup(match);
        }
      });
    }
  }

  Future<void> _loadExistingLineup(Match match) async {
    final players = await DatabaseService().getAllPlayers();

    // Load field positions
    match.fieldPositions.forEach((position, playerId) {
      final player = players.firstWhere(
        (p) => p.id.toString() == playerId,
        orElse: () => Player(),
      );
      if (player.id != 0) {
        _fieldPositions[position] = player;
      }
    });

    // Load bench players
    for (final playerId in match.substituteIds) {
      final player = players.firstWhere(
        (p) => p.id.toString() == playerId,
        orElse: () => Player(),
      );
      if (player.id != 0) {
        _benchPlayers.add(player);
      }
    }
  }

  void _initializePositions() {
    // Initialize field positions based on formation
    _fieldPositions = {
      'GK': null,
      'LB': null,
      'CB1': null,
      'CB2': null,
      'RB': null,
      'CM1': null,
      'CM2': null,
      'CM3': null,
      'LW': null,
      'ST': null,
      'RW': null,
    };
  }

  @override
  Widget build(BuildContext context) {
    final playersAsync = ref.watch(playersProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Opstelling Maken'),
        actions: [
          IconButton(
            icon: const Icon(Icons.save),
            onPressed: _saveLineup,
          ),
        ],
      ),
      body: playersAsync.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (error, stack) => Center(child: Text('Fout: $error')),
        data: (players) {
          _availablePlayers = players.where((p) =>
            !_fieldPositions.values.contains(p) && !_benchPlayers.contains(p)
          ).toList();

          return Row(
            children: [
              // Left side - Available players
              Expanded(
                flex: 2,
                child: Container(
                  color: Colors.grey[100],
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          'Beschikbare Spelers',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      Expanded(
                        child: ListView.builder(
                          padding: const EdgeInsets.all(8),
                          itemCount: _availablePlayers.length,
                          itemBuilder: (context, index) {
                            final player = _availablePlayers[index];
                            return Draggable<Player>(
                              data: player,
                              feedback: _buildPlayerChip(player, isDragging: true),
                              childWhenDragging: Opacity(
                                opacity: 0.5,
                                child: _buildPlayerCard(player),
                              ),
                              child: _buildPlayerCard(player),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),

              // Center - Field
              Expanded(
                flex: 5,
                child: Column(
                  children: [
                    // Formation selector
                    Container(
                      padding: const EdgeInsets.all(16),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          const Text('Formatie: '),
                          const SizedBox(width: 16),
                          DropdownButton<Formation>(
                            value: _selectedFormation,
                            items: Formation.values.map((formation) {
                              return DropdownMenuItem(
                                value: formation,
                                child: Text(_getFormationText(formation)),
                              );
                            }).toList(),
                            onChanged: (value) {
                              if (value != null) {
                                setState(() {
                                  _selectedFormation = value;
                                  _updateFormation();
                                });
                              }
                            },
                          ),
                        ],
                      ),
                    ),

                    // Field
                    Expanded(
                      child: Container(
                        margin: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: Colors.green[700],
                          borderRadius: BorderRadius.circular(8),
                          border: Border.all(color: Colors.white, width: 3),
                        ),
                        child: Stack(
                          children: _buildFieldPositions(),
                        ),
                      ),
                    ),
                  ],
                ),
              ),

              // Right side - Bench
              Expanded(
                flex: 2,
                child: Container(
                  color: Colors.grey[100],
                  child: Column(
                    children: [
                      Container(
                        padding: const EdgeInsets.all(16),
                        child: Text(
                          'Bank',
                          style: Theme.of(context).textTheme.titleLarge,
                        ),
                      ),
                      Expanded(
                        child: DragTarget<Player>(
                          onAccept: (player) {
                            setState(() {
                              // Remove from field if present
                              _fieldPositions.forEach((key, value) {
                                if (value == player) {
                                  _fieldPositions[key] = null;
                                }
                              });
                              // Add to bench if not already there
                              if (!_benchPlayers.contains(player)) {
                                _benchPlayers.add(player);
                              }
                            });
                          },
                          builder: (context, candidateData, rejectedData) {
                            return Container(
                              color: candidateData.isNotEmpty
                                ? Colors.blue.withOpacity(0.1)
                                : Colors.transparent,
                              child: ListView.builder(
                                padding: const EdgeInsets.all(8),
                                itemCount: _benchPlayers.length,
                                itemBuilder: (context, index) {
                                  final player = _benchPlayers[index];
                                  return Draggable<Player>(
                                    data: player,
                                    feedback: _buildPlayerChip(player, isDragging: true),
                                    childWhenDragging: Opacity(
                                      opacity: 0.5,
                                      child: _buildPlayerCard(player),
                                    ),
                                    onDragCompleted: () {
                                      setState(() {
                                        _benchPlayers.remove(player);
                                      });
                                    },
                                    child: _buildPlayerCard(player),
                                  );
                                },
                              ),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  List<Widget> _buildFieldPositions() {
    final positions = _getPositionsForFormation();
    return positions.entries.map((entry) {
      return Positioned(
        left: entry.value['x']! * MediaQuery.of(context).size.width * 0.4,
        top: entry.value['y']! * MediaQuery.of(context).size.height * 0.6,
        child: DragTarget<Player>(
          onAccept: (player) {
            setState(() {
              // Remove player from other positions
              _fieldPositions.forEach((key, value) {
                if (value == player) {
                  _fieldPositions[key] = null;
                }
              });
              _benchPlayers.remove(player);
              // Assign to new position
              _fieldPositions[entry.key] = player;
            });
          },
          builder: (context, candidateData, rejectedData) {
            final player = _fieldPositions[entry.key];
            return Container(
              width: 80,
              height: 80,
              decoration: BoxDecoration(
                color: candidateData.isNotEmpty
                  ? Colors.blue.withOpacity(0.3)
                  : Colors.white.withOpacity(0.9),
                shape: BoxShape.circle,
                border: Border.all(
                  color: Colors.black,
                  width: 2,
                ),
              ),
              child: player != null
                ? Draggable<Player>(
                    data: player,
                    feedback: _buildPlayerChip(player, isDragging: true),
                    childWhenDragging: Container(
                      decoration: BoxDecoration(
                        color: Colors.grey.withOpacity(0.5),
                        shape: BoxShape.circle,
                      ),
                    ),
                    onDragCompleted: () {
                      setState(() {
                        _fieldPositions[entry.key] = null;
                      });
                    },
                    child: _buildPlayerChip(player),
                  )
                : Center(
                    child: Text(
                      entry.key,
                      style: const TextStyle(
                        fontWeight: FontWeight.bold,
                        fontSize: 12,
                      ),
                    ),
                  ),
            );
          },
        ),
      );
    }).toList();
  }

  Widget _buildPlayerCard(Player player) {
    return Card(
      margin: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: _getPositionColor(player.position),
          child: Text(
            player.jerseyNumber.toString(),
            style: const TextStyle(color: Colors.white),
          ),
        ),
        title: Text('${player.firstName} ${player.lastName}'),
        subtitle: Text(_getPositionText(player.position)),
        dense: true,
      ),
    );
  }

  Widget _buildPlayerChip(Player player, {bool isDragging = false}) {
    return Material(
      elevation: isDragging ? 8 : 0,
      shape: const CircleBorder(),
      child: Container(
        width: 80,
        height: 80,
        decoration: BoxDecoration(
          color: _getPositionColor(player.position),
          shape: BoxShape.circle,
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(
              player.jerseyNumber.toString(),
              style: const TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: 20,
              ),
            ),
            Text(
              player.lastName,
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
              ),
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }

  Map<String, Map<String, double>> _getPositionsForFormation() {
    switch (_selectedFormation) {
      case Formation.fourFourTwo:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'LB': {'x': 0.15, 'y': 0.7},
          'CB1': {'x': 0.35, 'y': 0.75},
          'CB2': {'x': 0.65, 'y': 0.75},
          'RB': {'x': 0.85, 'y': 0.7},
          'LM': {'x': 0.15, 'y': 0.45},
          'CM1': {'x': 0.35, 'y': 0.5},
          'CM2': {'x': 0.65, 'y': 0.5},
          'RM': {'x': 0.85, 'y': 0.45},
          'ST1': {'x': 0.35, 'y': 0.2},
          'ST2': {'x': 0.65, 'y': 0.2},
        };
      case Formation.fourFourTwoDiamond:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'LB': {'x': 0.15, 'y': 0.7},
          'CB1': {'x': 0.35, 'y': 0.75},
          'CB2': {'x': 0.65, 'y': 0.75},
          'RB': {'x': 0.85, 'y': 0.7},
          'DM': {'x': 0.5, 'y': 0.6},
          'LM': {'x': 0.25, 'y': 0.45},
          'RM': {'x': 0.75, 'y': 0.45},
          'AM': {'x': 0.5, 'y': 0.35},
          'ST1': {'x': 0.35, 'y': 0.15},
          'ST2': {'x': 0.65, 'y': 0.15},
        };
      case Formation.fourThreeThree:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'LB': {'x': 0.15, 'y': 0.7},
          'CB1': {'x': 0.35, 'y': 0.75},
          'CB2': {'x': 0.65, 'y': 0.75},
          'RB': {'x': 0.85, 'y': 0.7},
          'CM1': {'x': 0.3, 'y': 0.5},
          'CM2': {'x': 0.5, 'y': 0.45},
          'CM3': {'x': 0.7, 'y': 0.5},
          'LW': {'x': 0.2, 'y': 0.2},
          'ST': {'x': 0.5, 'y': 0.15},
          'RW': {'x': 0.8, 'y': 0.2},
        };
      case Formation.fourThreeThreeDefensive:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'LB': {'x': 0.15, 'y': 0.7},
          'CB1': {'x': 0.35, 'y': 0.75},
          'CB2': {'x': 0.65, 'y': 0.75},
          'RB': {'x': 0.85, 'y': 0.7},
          'DM': {'x': 0.5, 'y': 0.55},
          'CM1': {'x': 0.3, 'y': 0.45},
          'CM2': {'x': 0.7, 'y': 0.45},
          'LW': {'x': 0.2, 'y': 0.25},
          'ST': {'x': 0.5, 'y': 0.2},
          'RW': {'x': 0.8, 'y': 0.25},
        };
      case Formation.threeForThree:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'CB1': {'x': 0.25, 'y': 0.75},
          'CB2': {'x': 0.5, 'y': 0.7},
          'CB3': {'x': 0.75, 'y': 0.75},
          'LM': {'x': 0.15, 'y': 0.5},
          'CM1': {'x': 0.35, 'y': 0.5},
          'CM2': {'x': 0.65, 'y': 0.5},
          'RM': {'x': 0.85, 'y': 0.5},
          'LW': {'x': 0.2, 'y': 0.2},
          'ST': {'x': 0.5, 'y': 0.15},
          'RW': {'x': 0.8, 'y': 0.2},
        };
      case Formation.fourTwoThreeOne:
        return {
          'GK': {'x': 0.5, 'y': 0.9},
          'LB': {'x': 0.15, 'y': 0.7},
          'CB1': {'x': 0.35, 'y': 0.75},
          'CB2': {'x': 0.65, 'y': 0.75},
          'RB': {'x': 0.85, 'y': 0.7},
          'DM1': {'x': 0.35, 'y': 0.55},
          'DM2': {'x': 0.65, 'y': 0.55},
          'LW': {'x': 0.2, 'y': 0.35},
          'AM': {'x': 0.5, 'y': 0.3},
          'RW': {'x': 0.8, 'y': 0.35},
          'ST': {'x': 0.5, 'y': 0.1},
        };
    }
  }

  void _updateFormation() {
    // Clear current positions
    _fieldPositions.clear();
    _initializePositions();
  }

  void _saveLineup() async {
    if (_match != null) {
      // Save lineup to match
      _match!.selectedFormation = _selectedFormation;
      _match!.startingLineupIds = _fieldPositions.entries
          .where((e) => e.value != null)
          .map((e) => e.value!.id.toString())
          .toList();
      _match!.substituteIds = _benchPlayers.map((p) => p.id.toString()).toList();

      // Save field positions
      _match!.fieldPositions = {};
      _fieldPositions.forEach((position, player) {
        if (player != null) {
          _match!.fieldPositions[position] = player.id.toString();
        }
      });

      await DatabaseService().updateMatch(_match!);

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
            content: Text('Opstelling opgeslagen voor wedstrijd'),
            backgroundColor: Colors.green,
          ),
        );
        // Use go to navigate back to match detail
        if (widget.matchId != null) {
          context.go('/matches/${widget.matchId}');
        }
      }
    } else {
      // Just show saved message for standalone lineup
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Opstelling opgeslagen'),
          backgroundColor: Colors.green,
        ),
      );
      context.go('/dashboard');
    }
  }

  Color _getPositionColor(Position position) {
    switch (position) {
      case Position.goalkeeper:
        return Colors.orange;
      case Position.defender:
        return Colors.blue;
      case Position.midfielder:
        return Colors.green;
      case Position.forward:
        return Colors.red;
    }
  }

  String _getPositionText(Position position) {
    switch (position) {
      case Position.goalkeeper:
        return 'Keeper';
      case Position.defender:
        return 'Verdediger';
      case Position.midfielder:
        return 'Middenvelder';
      case Position.forward:
        return 'Aanvaller';
    }
  }

  String _getFormationText(Formation formation) {
    switch (formation) {
      case Formation.fourFourTwo:
        return '4-4-2';
      case Formation.fourFourTwoDiamond:
        return '4-4-2 (Ruit)';
      case Formation.fourThreeThree:
        return '4-3-3';
      case Formation.fourThreeThreeDefensive:
        return '4-3-3 (Verdedigend)';
      case Formation.threeForThree:
        return '3-4-3';
      case Formation.fourTwoThreeOne:
        return '4-2-3-1';
    }
  }
}
