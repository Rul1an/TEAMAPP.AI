import 'package:isar/isar.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter/foundation.dart' show kIsWeb;
import '../models/team.dart';
import '../models/player.dart';
import '../models/training.dart';
import '../models/match.dart';

class DatabaseService {
  static final DatabaseService _instance = DatabaseService._internal();
  factory DatabaseService() => _instance;
  DatabaseService._internal();

  Isar? _isar;
  bool _isInitialized = false;

  // In-memory storage for web
  final List<Team> _teams = [];
  final List<Player> _players = [];
  final List<Training> _trainings = [];
  final List<Match> _matches = [];

  Future<Isar?> get isar async {
    if (_isar != null) return _isar;
    if (!kIsWeb) {
      await initialize();
    }
    return _isar;
  }

  Future<void> initialize() async {
    if (_isInitialized) return;
    _isInitialized = true;

    if (!kIsWeb) {
      final dir = await getApplicationDocumentsDirectory();

      // TODO: Enable when Isar schemas are generated
      // _isar = await Isar.open(
      //   [
      //     TeamSchema,
      //     PlayerSchema,
      //     TrainingSchema,
      //     MatchSchema,
      //   ],
      //   directory: dir.path,
      // );
    }

    // Initialize with sample data only if empty
    if (_players.isEmpty) {
      await _initializeSampleData();
    }
  }

  Future<void> _initializeSampleData() async {
    // Add sample team
    final team = Team()
      ..id = 1
      ..name = 'JO17-1'
      ..ageGroup = 'JO17'
      ..season = '2024-2025'
      ..preferredFormation = Formation.fourThreeThree
      ..matchesPlayed = 10
      ..wins = 6
      ..draws = 2
      ..losses = 2
      ..goalsFor = 25
      ..goalsAgainst = 12;

    _teams.add(team);

    // Add sample players
    final positions = [
      Position.goalkeeper,
      Position.defender, Position.defender, Position.defender, Position.defender,
      Position.midfielder, Position.midfielder, Position.midfielder,
      Position.forward, Position.forward, Position.forward,
    ];

    final names = [
      ('Lars', 'de Jong'), ('Tom', 'Bakker'), ('Daan', 'Visser'),
      ('Sem', 'de Vries'), ('Lucas', 'van Dijk'), ('Finn', 'Jansen'),
      ('Milan', 'de Boer'), ('Jesse', 'Mulder'), ('Thijs', 'Peters'),
      ('Max', 'Hendriks'), ('Noah', 'van der Berg'),
    ];

    for (int i = 0; i < names.length; i++) {
      final player = Player()
        ..id = i + 1
        ..firstName = names[i].$1
        ..lastName = names[i].$2
        ..jerseyNumber = i + 1
        ..birthDate = DateTime.now().subtract(Duration(days: 6000 + (i * 30)))
        ..position = positions[i]
        ..preferredFoot = i % 3 == 0 ? PreferredFoot.left : PreferredFoot.right
        ..height = 165.0 + (i * 2)
        ..weight = 55.0 + (i * 1.5)
        ..matchesPlayed = 8 + (i % 3)
        ..goals = i > 7 ? 3 + i : 0
        ..assists = i > 5 ? 2 + (i % 3) : 0
        ..trainingsAttended = 18 + (i % 5)
        ..trainingsTotal = 20;

      _players.add(player);
    }

    // Add sample trainings
    for (int i = 0; i < 5; i++) {
      final training = Training()
        ..id = i + 1
        ..date = DateTime.now().add(Duration(days: i * 2))
        ..duration = 90
        ..focus = TrainingFocus.values[i % TrainingFocus.values.length]
        ..intensity = TrainingIntensity.values[i % TrainingIntensity.values.length]
        ..status = i < 2 ? TrainingStatus.completed : TrainingStatus.planned
        ..location = 'Sportpark De Toekomst'
        ..presentPlayerIds = _players.take(9).map((p) => p.id.toString()).toList()
        ..absentPlayerIds = _players.skip(9).map((p) => p.id.toString()).toList();

      _trainings.add(training);
    }

    // Add sample matches
    final opponents = ['Ajax JO17', 'PSV JO17', 'Feyenoord JO17', 'AZ JO17', 'Utrecht JO17'];
    for (int i = 0; i < 5; i++) {
      final match = Match()
        ..id = i + 1
        ..date = DateTime.now().add(Duration(days: i * 7))
        ..opponent = opponents[i]
        ..location = i % 2 == 0 ? Location.home : Location.away
        ..competition = Competition.league
        ..status = i < 2 ? MatchStatus.completed : MatchStatus.scheduled
        ..venue = i % 2 == 0 ? 'Sportpark De Toekomst' : 'Uitstadion'
        ..teamScore = i < 2 ? 2 + i : null
        ..opponentScore = i < 2 ? 1 : null;

      _matches.add(match);
    }

    print('Sample data initialized with ${_players.length} players');
  }

  // Team operations
  Future<void> saveTeam(Team team) async {
    team.updatedAt = DateTime.now();
    if (kIsWeb) {
      final index = _teams.indexWhere((t) => t.id == team.id);
      if (index >= 0) {
        _teams[index] = team;
      } else {
        if (team.id == Isar.autoIncrement) {
          team.id = (_teams.map((t) => t.id).fold(0, (a, b) => a > b ? a : b) + 1);
        }
        _teams.add(team);
      }
    } else {
      // TODO: Implement Isar save
    }
  }

  Future<Team?> getTeam(int id) async {
    if (kIsWeb) {
      try {
        return _teams.firstWhere((t) => t.id == id);
      } catch (_) {
        return null;
      }
    }
    // TODO: Implement Isar get
    return null;
  }

  Future<List<Team>> getAllTeams() async {
    if (kIsWeb) {
      return List.from(_teams);
    }
    // TODO: Implement Isar getAll
    return [];
  }

  // Player operations
  Future<void> savePlayer(Player player) async {
    player.updatedAt = DateTime.now();
    if (kIsWeb) {
      final index = _players.indexWhere((p) => p.id == player.id);
      if (index >= 0) {
        _players[index] = player;
      } else {
        if (player.id == Isar.autoIncrement) {
          player.id = (_players.map((p) => p.id).fold(0, (a, b) => a > b ? a : b) + 1);
        }
        _players.add(player);
        print('Player added: ${player.firstName} ${player.lastName} with ID ${player.id}');
      }
    } else {
      // TODO: Implement Isar save
    }
  }

  Future<Player?> getPlayer(int id) async {
    if (kIsWeb) {
      try {
        return _players.firstWhere((p) => p.id == id);
      } catch (_) {
        return null;
      }
    }
    // TODO: Implement Isar get
    return null;
  }

  Future<List<Player>> getAllPlayers() async {
    if (kIsWeb) {
      print('Getting all players: ${_players.length} players found');
      return List.from(_players);
    }
    // TODO: Implement Isar getAll
    return [];
  }

  Future<List<Player>> getPlayersByPosition(Position position) async {
    if (kIsWeb) {
      return _players.where((p) => p.position == position).toList();
    }
    // TODO: Implement Isar query
    return [];
  }

  Future<void> updatePlayer(Player player) async {
    // Mock implementation
    final index = _players.indexWhere((p) => p.id == player.id);
    if (index != -1) {
      _players[index] = player;
    }
  }

  Future<void> deletePlayer(int playerId) async {
    // Mock implementation
    _players.removeWhere((p) => p.id == playerId);
  }

  // Training operations
  Future<void> saveTraining(Training training) async {
    training.updatedAt = DateTime.now();
    if (kIsWeb) {
      final index = _trainings.indexWhere((t) => t.id == training.id);
      if (index >= 0) {
        _trainings[index] = training;
      } else {
        if (training.id == Isar.autoIncrement) {
          training.id = (_trainings.map((t) => t.id).fold(0, (a, b) => a > b ? a : b) + 1);
        }
        _trainings.add(training);
      }
    } else {
      // TODO: Implement Isar save
    }
  }

  Future<List<Training>> getAllTrainings() async {
    if (kIsWeb) {
      return List.from(_trainings);
    }
    // TODO: Implement Isar getAll
    return [];
  }

  Future<List<Training>> getUpcomingTrainings() async {
    final now = DateTime.now();
    if (kIsWeb) {
      return _trainings
          .where((t) => t.date.isAfter(now) && t.status == TrainingStatus.planned)
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));
    }
    // TODO: Implement Isar query
    return [];
  }

  Future<List<Training>> getTrainingsForDateRange(DateTime start, DateTime end) async {
    if (kIsWeb) {
      return _trainings
          .where((t) => t.date.isAfter(start) && t.date.isBefore(end))
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));
    }
    // TODO: Implement Isar query
    return [];
  }

  // Match operations
  Future<void> saveMatch(Match match) async {
    match.updatedAt = DateTime.now();
    if (kIsWeb) {
      final index = _matches.indexWhere((m) => m.id == match.id);
      if (index >= 0) {
        _matches[index] = match;
      } else {
        if (match.id == Isar.autoIncrement) {
          match.id = (_matches.map((m) => m.id).fold(0, (a, b) => a > b ? a : b) + 1);
        }
        _matches.add(match);
        print('Match added: ${match.opponent} on ${match.date}');
      }
    } else {
      // TODO: Implement Isar save
    }
  }

  Future<Match?> getMatch(int id) async {
    if (kIsWeb) {
      try {
        return _matches.firstWhere((m) => m.id == id);
      } catch (_) {
        return null;
      }
    }
    // TODO: Implement Isar get
    return null;
  }

  Future<List<Match>> getAllMatches() async {
    if (kIsWeb) {
      return List.from(_matches);
    }
    // TODO: Implement Isar getAll
    return [];
  }

  Future<List<Match>> getUpcomingMatches() async {
    final now = DateTime.now();
    if (kIsWeb) {
      return _matches
          .where((m) => m.date.isAfter(now) && m.status == MatchStatus.scheduled)
          .toList()
        ..sort((a, b) => a.date.compareTo(b.date));
    }
    // TODO: Implement Isar query
    return [];
  }

  Future<List<Match>> getRecentMatches({int limit = 5}) async {
    if (kIsWeb) {
      final completed = _matches
          .where((m) => m.status == MatchStatus.completed)
          .toList()
        ..sort((a, b) => b.date.compareTo(a.date));
      return completed.take(limit).toList();
    }
    // TODO: Implement Isar query
    return [];
  }

  // Statistics
  Future<Map<String, dynamic>> getStatistics() async {
    final players = await getAllPlayers();
    final trainings = await getAllTrainings();
    final matches = await getAllMatches();
    final completedMatches = matches.where((m) => m.status == MatchStatus.completed).toList();

    int wins = 0;
    int draws = 0;
    int losses = 0;
    int goalsFor = 0;
    int goalsAgainst = 0;

    for (final match in completedMatches) {
      if (match.teamScore != null && match.opponentScore != null) {
        goalsFor += match.teamScore!;
        goalsAgainst += match.opponentScore!;

        if (match.teamScore! > match.opponentScore!) {
          wins++;
        } else if (match.teamScore! < match.opponentScore!) {
          losses++;
        } else {
          draws++;
        }
      }
    }

    final totalMatches = wins + draws + losses;
    final winPercentage = totalMatches > 0 ? (wins / totalMatches) * 100 : 0.0;

    return {
      'totalPlayers': players.length,
      'totalTrainings': trainings.length,
      'totalMatches': matches.length,
      'winPercentage': winPercentage,
      'wins': wins,
      'draws': draws,
      'losses': losses,
      'goalsFor': goalsFor,
      'goalsAgainst': goalsAgainst,
      'goalDifference': goalsFor - goalsAgainst,
    };
  }

  // Matches
  Future<List<Match>> getMatches() async {
    // Mock implementation
    return _matches;
  }

  Future<void> addMatch(Match match) async {
    // Mock implementation
    match.id = _matches.length + 1;
    _matches.add(match);
  }

  Future<void> updateMatch(Match match) async {
    // Mock implementation
    await Future.delayed(const Duration(milliseconds: 500));

    final index = _matches.indexWhere((m) => m.id == match.id);
    if (index != -1) {
      _matches[index] = match;
    }
  }

  Future<void> deleteMatch(int matchId) async {
    // Mock implementation
    _matches.removeWhere((m) => m.id == matchId);
  }

  // Trainings
  Future<List<Training>> getTrainings() async {
    // Mock implementation
    return _trainings;
  }

  Future<void> updateTraining(Training training) async {
    // Mock implementation
    await Future.delayed(const Duration(milliseconds: 500));

    final index = _trainings.indexWhere((t) => t.id == training.id);
    if (index != -1) {
      _trainings[index] = training;
    }
  }

  Future<void> deleteTraining(int id) async {
    // Mock implementation
    await Future.delayed(const Duration(milliseconds: 500));
    _trainings.removeWhere((t) => t.id == id);
  }
}
